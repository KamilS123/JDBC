create trigger moj_trigerek
  after INSERT
  on studenci
  for each row
  BEGIN
INSERT INTO studenci_rzeszow SELECT * FROM studenci WHERE id_studenta = max(id_studenta);
END;

